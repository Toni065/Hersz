//=============== IMPORT ===============
const { default: MakeWASocket, useMultiFileAuthState, DisconnectReason, makeCacheableSignalKeyStore, fetchLatestBaileysVersion } = require('@bayumahadika/baileys')
const pino = require('pino')
const fs = require('fs')
const path = require('path')
const chalk = require('chalk')
const log = require('pino')({ level: 'silent' })

//=============== KONFIGURASI GLOBAL ===============
const config = require('./config')
const handler = require('./handler') // misal handler kamu sudah pisah

//=============== FUNGSI UTAMA ===============
async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('./session') // auth state folder
    const { version } = await fetchLatestBaileysVersion()

    const sock = MakeWASocket({
        version,
        printQRInTerminal: true,
        logger: log,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, log)
        },
        browser: ['Bot WhatsApp', 'Chrome', '121.0.0.0']
    })

    //=============== EVENT HANDLER ===============
    sock.ev.on('creds.update', saveCreds)
    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update
        if (connection === 'close') {
            const reason = lastDisconnect?.error?.output?.statusCode
            if (reason === DisconnectReason.loggedOut) {
                console.log(chalk.red('❌ Terlogout. Hapus session dan scan ulang.'))
                process.exit()
            } else {
                console.log(chalk.yellow('🔄 Reconnecting...'))
                startBot()
            }
        } else if (connection === 'open') {
            console.log(chalk.green('✅ Terhubung ke WhatsApp!'))
        }
    })

    //=============== PESAN MASUK ===============
    sock.ev.on('messages.upsert', async ({ messages }) => {
        const m = messages[0]
        if (!m.message || m.key.fromMe) return

        try {
            await handler(sock, m, config) // kamu bisa sesuaikan handler-nya
        } catch (err) {
            console.error(chalk.red('❌ Error di handler:'), err)
        }
    })
}

//=============== JALANKAN BOT ===============
startBot()