function _0xb1c8() {
  const _0x36cffd = [
    '3355255jCPXFG',
    '9122477wxmJwV',
    'html5player.setVideoHLS\x5c(\x27(.*?)\x27\x5c);',
    'now',
    'filter',
    '894960OvSceh',
    'div.user__title\x20>\x20h4',
    'div[class=\x22col-7\x20col-md-auto\x20text-truncate\x22]',
    '30188QnesTo',
    'stringify',
    'background-image:\x20url(\x27',
    'error',
    'https://2chat.c3r.ink/',
    '20183672omJNpO',
    '#html5video\x20>\x20#html5video_base\x20>\x20div\x20>\x20a',
    'parse',
    'https://fdownloader.net/api/ajaxSearch',
    'value',
    'set-cookie',
    'span.video-hd-mark',
    'attr',
    'pop',
    'request',
    'href',
    'div.mozaique\x20>\x20div\x20>\x20div\x20>\x20div.thumb\x20>\x20a',
    '\x20views',
    '/THUMBNUM/',
    'h1.user',
    'div.user__info-desc',
    'div.thumb-under\x20a',
    'toArray',
    'POST',
    'src',
    'map',
    'application/x-www-form-urlencoded;\x20charset=UTF-8',
    'split',
    'each',
    'https://www.xvideos.com/?k=',
    'div.content\x20>\x20p',
    '\x27);',
    'span.rating-bad-nbr',
    'meta[property=\x27og:title\x27]',
    'div.thumb\x20a',
    'username',
    'followers',
    '\x22images\x22:',
    'length',
    'https://chatapicn.a3r.fun/api/chat-process',
    '213gmskUi',
    '&p=',
    'content',
    'replace',
    'find',
    'div.user__img',
    'https://fdownloader.net/',
    'data-src',
    'description',
    'html',
    'load',
    'div#video-tabs\x20>\x20div\x20>\x20div\x20>\x20div\x20>\x20div\x20>\x20strong.mobile-hide',
    '749184OPaMpW',
    'title',
    'data',
    'entries',
    'style',
    'div.user__title\x20>\x20a\x20>\x20h1',
    'get',
    '/search/',
    'trim',
    'text',
    'match',
    'floor',
    '#video-player-bg\x20>\x20script:nth-child(6)',
    'div[class=\x22col-md-auto\x20justify-content-center\x20text-center\x22]\x20>\x20img',
    'random',
    'post',
    '1739701oQHsnr',
    'push',
    'div[class=\x22col-auto\x20d-none\x20d-sm-block\x20text-truncate\x22]',
    'div.mozaique',
    'json',
    'script',
  ]
  _0xb1c8 = function () {
    return _0x36cffd
  }
  return _0xb1c8()
}
;(function (_0x5d0954, _0x79750a) {
  const _0x1c320e = _0x24da,
    _0x233698 = _0x5d0954()
  while (!![]) {
    try {
      const _0xe942b =
        parseInt(_0x1c320e(0x11b)) / 0x1 +
        (-parseInt(_0x1c320e(0x129)) / 0x2) * (-parseInt(_0x1c320e(0xff)) / 0x3) +
        -parseInt(_0x1c320e(0x10b)) / 0x4 +
        -parseInt(_0x1c320e(0x121)) / 0x5 +
        parseInt(_0x1c320e(0x126)) / 0x6 +
        parseInt(_0x1c320e(0x122)) / 0x7 +
        -parseInt(_0x1c320e(0x12e)) / 0x8
      if (_0xe942b === _0x79750a) break
      else _0x233698['push'](_0x233698['shift']())
    } catch (_0x460fb0) {
      _0x233698['push'](_0x233698['shift']())
    }
  }
})(_0xb1c8, 0xd7708)
const _0xf85905 = require('cheerio')
function _0x24da(_0x2e6dae, _0x2d5eab) {
  const _0xb1c8b5 = _0xb1c8()
  return (
    (_0x24da = function (_0x24da6b, _0x3cec82) {
      _0x24da6b = _0x24da6b - 0xfe
      let _0x144e24 = _0xb1c8b5[_0x24da6b]
      return _0x144e24
    }),
    _0x24da(_0x2e6dae, _0x2d5eab)
  )
}
const _0x3e64a6 = require('node-fetch')
const _0x1446b3 = require('axios')
async function sekaikomikDl(_0x281ece) {
  const _0x4752aa = _0x24da
  let _0x44a26d = await _0x3e64a6(_0x281ece),
    _0x25e5f8 = _0xf85905[_0x4752aa(0x109)](await _0x44a26d['text']()),
    _0x546e7f = _0x25e5f8(_0x4752aa(0x120))
      [_0x4752aa(0x142)]((_0x597dd9, _0x56d025) => _0x25e5f8(_0x56d025)[_0x4752aa(0x108)]())
      [_0x4752aa(0x13f)]()
  return (
    (_0x546e7f = _0x546e7f[_0x4752aa(0x125)](_0x435fb6 => /wp-content/i['test'](_0x435fb6))),
    (_0x546e7f = eval(_0x546e7f[0x0]['split'](_0x4752aa(0x14e))[0x1]['split']('}],')[0x0])),
    _0x546e7f['map'](_0x426296 => encodeURI(_0x426296))
  )
}
async function facebookDl(_0x5bfb47) {
  const _0xc418ce = _0x24da
  let _0x236170 = await _0x3e64a6('https://fdownloader.net/'),
    _0x138dbf = _0xf85905[_0xc418ce(0x109)](await _0x236170[_0xc418ce(0x114)]()),
    _0x353382 = _0x138dbf('input[name=\x22__RequestVerificationToken\x22]')[_0xc418ce(0x135)](
      _0xc418ce(0x132)
    ),
    _0x5cd298 = await (
      await _0x3e64a6(_0xc418ce(0x131), {
        method: _0xc418ce(0x11a),
        headers: {
          cookie: _0x236170['headers'][_0xc418ce(0x111)](_0xc418ce(0x133)),
          'content-type': _0xc418ce(0x143),
          referer: _0xc418ce(0x105),
        },
        body: new URLSearchParams(
          Object[_0xc418ce(0x10e)]({ __RequestVerificationToken: _0x353382, q: _0x5bfb47 })
        ),
      })
    )[_0xc418ce(0x11f)](),
    _0x4376b2 = _0xf85905['load'](_0x5cd298['data']),
    _0x4f15ed = {}
  return (
    _0x4376b2('.button.is-success.is-small.download-link-fb')[_0xc418ce(0x145)](function () {
      const _0x5ccc4c = _0xc418ce
      let _0x1e455e = _0x4376b2(this)[_0x5ccc4c(0x135)](_0x5ccc4c(0x10c))['split']('\x20')[0x1],
        _0x24048d = _0x4376b2(this)[_0x5ccc4c(0x135)](_0x5ccc4c(0x138))
      if (_0x24048d) _0x4f15ed[_0x1e455e] = _0x24048d
    }),
    _0x4f15ed
  )
}
async function tiktokStalk(_0x292c3a) {
  const _0x2fdbfb = _0x24da
  let _0x4a75a7 = await _0x1446b3[_0x2fdbfb(0x111)]('https://urlebird.com/user/' + _0x292c3a + '/'),
    _0x43f41b = _0xf85905['load'](_0x4a75a7['data']),
    _0x3760e1 = {}
  return (
    (_0x3760e1['pp_user'] = _0x43f41b(_0x2fdbfb(0x118))[_0x2fdbfb(0x135)](_0x2fdbfb(0x141))),
    (_0x3760e1['name'] = _0x43f41b(_0x2fdbfb(0x13c))[_0x2fdbfb(0x114)]()[_0x2fdbfb(0x113)]()),
    (_0x3760e1[_0x2fdbfb(0x14c)] = _0x43f41b('div.content\x20>\x20h5')
      ['text']()
      [_0x2fdbfb(0x113)]()),
    (_0x3760e1[_0x2fdbfb(0x14d)] = _0x43f41b(_0x2fdbfb(0x128))
      [_0x2fdbfb(0x114)]()
      [_0x2fdbfb(0x113)]()
      [_0x2fdbfb(0x144)]('\x20')[0x1]),
    (_0x3760e1['following'] = _0x43f41b(_0x2fdbfb(0x11d))
      [_0x2fdbfb(0x114)]()
      ['trim']()
      [_0x2fdbfb(0x144)]('\x20')[0x1]),
    (_0x3760e1[_0x2fdbfb(0x107)] = _0x43f41b(_0x2fdbfb(0x147))[_0x2fdbfb(0x114)]()['trim']()),
    _0x3760e1
  )
}
async function igStalk(_0x3a0bc2) {
  const _0x48d4cb = _0x24da
  _0x3a0bc2 = _0x3a0bc2['replace'](/^@/, '')
  const _0x2e793d = await (
      await _0x3e64a6('https://dumpor.com/v/' + _0x3a0bc2)
    )[_0x48d4cb(0x114)](),
    _0xde4576 = _0xf85905['load'](_0x2e793d),
    _0x14ff71 = _0xde4576(_0x48d4cb(0x110))[_0x48d4cb(0x114)]()[_0x48d4cb(0x113)](),
    _0xc30c04 = _0xde4576(_0x48d4cb(0x127))['text']()['trim'](),
    _0x1aca7d = _0xde4576(_0x48d4cb(0x13d))[_0x48d4cb(0x114)]()[_0x48d4cb(0x113)](),
    _0x266f9c = _0xde4576(_0x48d4cb(0x104))
      [_0x48d4cb(0x135)](_0x48d4cb(0x10f))
      ?.[_0x48d4cb(0x102)](_0x48d4cb(0x12b), '')
      [_0x48d4cb(0x102)](_0x48d4cb(0x148), ''),
    _0x460da5 = _0xde4576(
      '#user-page\x20>\x20div.container\x20>\x20div\x20>\x20div\x20>\x20div:nth-child(1)\x20>\x20div\x20>\x20a'
    ),
    _0xebbfc7 = _0x460da5['eq'](0x0)
      [_0x48d4cb(0x114)]()
      [_0x48d4cb(0x102)](/Posts/i, '')
      [_0x48d4cb(0x113)](),
    _0x52ad58 = _0x460da5['eq'](0x2)
      [_0x48d4cb(0x114)]()
      ['replace'](/Followers/i, '')
      [_0x48d4cb(0x113)](),
    _0x1b6476 = _0x460da5['eq'](0x3)
      ['text']()
      [_0x48d4cb(0x102)](/Following/i, '')
      ['trim'](),
    _0x4ecd71 = _0xde4576('ul.list\x20>\x20li.list__item'),
    _0x54ee6e = parseInt(
      _0x4ecd71['eq'](0x0)
        [_0x48d4cb(0x114)]()
        [_0x48d4cb(0x102)](/Posts/i, '')
        [_0x48d4cb(0x113)]()
        [_0x48d4cb(0x102)](/\s/g, '')
    ),
    _0x39d01b = parseInt(
      _0x4ecd71['eq'](0x1)
        [_0x48d4cb(0x114)]()
        [_0x48d4cb(0x102)](/Followers/i, '')
        [_0x48d4cb(0x113)]()
        [_0x48d4cb(0x102)](/\s/g, '')
    ),
    _0xba97c2 = parseInt(
      _0x4ecd71['eq'](0x2)
        [_0x48d4cb(0x114)]()
        [_0x48d4cb(0x102)](/Following/i, '')
        [_0x48d4cb(0x113)]()
        [_0x48d4cb(0x102)](/\s/g, '')
    )
  return {
    name: _0x14ff71,
    username: _0xc30c04,
    description: _0x1aca7d,
    postsH: _0xebbfc7,
    posts: _0x54ee6e,
    followersH: _0x52ad58,
    followers: _0x39d01b,
    followingH: _0x1b6476,
    following: _0xba97c2,
    profilePic: _0x266f9c,
  }
}
async function xnxxdl(_0x4ced3c) {
  const _0x36b936 = _0x24da
  try {
    const _0x6385f6 = await _0x3e64a6(_0x4ced3c),
      _0x570089 = await _0x6385f6[_0x36b936(0x114)](),
      _0x58de88 = _0xf85905[_0x36b936(0x109)](_0x570089),
      _0x5a205f = _0x58de88(_0x36b936(0x117))['html'](),
      _0x4e5a96 = {
        low: (_0x5a205f[_0x36b936(0x115)]('html5player.setVideoUrlLow\x5c(\x27(.*?)\x27\x5c);') ||
          [])[0x1],
        high: _0x5a205f[_0x36b936(0x115)](
          'html5player.setVideoUrlHigh\x5c(\x27(.*?)\x27\x5c);' || []
        )[0x1],
        HLS: _0x5a205f[_0x36b936(0x115)](_0x36b936(0x123) || [])[0x1],
      }
    return _0x4e5a96
  } catch (_0x322bfb) {
    return console[_0x36b936(0x12c)](_0x322bfb), null
  }
}
async function xnxxSearch(_0x58b8be) {
  const _0x16b263 = _0x24da,
    _0x5010f7 = 'https://www.xnxx.com',
    _0x5f5b5e = await _0x3e64a6(
      _0x5010f7 +
        _0x16b263(0x112) +
        _0x58b8be +
        '/' +
        (Math[_0x16b263(0x116)](Math[_0x16b263(0x119)]() * 0x3) + 0x1),
      { method: 'get' }
    ),
    _0xf396b = await _0x5f5b5e[_0x16b263(0x114)](),
    _0x251c69 = _0xf85905['load'](_0xf396b, { xmlMode: ![] })
  let _0x57c20f = []
  return (
    _0x251c69(_0x16b263(0x11e))['each'](function (_0x50cb8d, _0x5b2ed4) {
      const _0x13d61e = _0x16b263,
        _0x346297 = _0x251c69(_0x5b2ed4)
          [_0x13d61e(0x103)](_0x13d61e(0x14b))
          [_0x13d61e(0x142)](
            (_0x40f1c0, _0x10be25) =>
              _0x5010f7 +
              _0x251c69(_0x10be25)
                [_0x13d61e(0x135)](_0x13d61e(0x138))
                [_0x13d61e(0x102)](_0x13d61e(0x13b), '/')
          )
          [_0x13d61e(0x111)](),
        _0x105025 = _0x251c69(_0x5b2ed4)
          [_0x13d61e(0x103)](_0x13d61e(0x13e))
          [_0x13d61e(0x142)]((_0x17dbd9, _0x1d7567) =>
            _0x251c69(_0x1d7567)['attr'](_0x13d61e(0x10c))
          )
          [_0x13d61e(0x111)]()
      for (let _0x215346 = 0x0; _0x215346 < _0x346297[_0x13d61e(0x14f)]; _0x215346++) {
        _0x57c20f[_0x13d61e(0x11c)]({ title: _0x105025[_0x215346], link: _0x346297[_0x215346] })
      }
    }),
    _0x57c20f
  )
}
async function ChatGpt(_0xe20f1f, _0x344017) {
  const _0x121947 = _0x24da,
    _0x23be9d = {
      method: _0x121947(0x140),
      headers: {
        'Content-Type': 'application/json',
        Referer: _0x121947(0x12d),
        accept: 'application/json,\x20text/plain,\x20*/*',
      },
      body: JSON[_0x121947(0x12a)]({
        prompt: _0xe20f1f,
        options: {},
        regenerate: ![],
        roomId: 0x3ea,
        uuid: Date[_0x121947(0x124)](),
        systemMessage: _0x344017,
        top_p: 0x1,
        temperature: 0.8,
      }),
    },
    _0x478037 = await _0x3e64a6(_0x121947(0xfe), _0x23be9d),
    _0x1a83a0 = await _0x478037['text']()
  let _0x10afe7 = JSON[_0x121947(0x130)](_0x1a83a0[_0x121947(0x144)]('\x0a')[_0x121947(0x136)]())
  return _0x10afe7
}
async function xvideosSearch(_0x28993e) {
  return new Promise(async _0x610d9 => {
    const _0x524197 = _0x24da,
      _0x2f9041 = await _0x1446b3[_0x524197(0x137)](
        _0x524197(0x146) +
          _0x28993e +
          _0x524197(0x100) +
          (Math[_0x524197(0x116)](Math[_0x524197(0x119)]() * 0x9) + 0x1),
        { method: _0x524197(0x111) }
      ),
      _0x585cba = _0xf85905[_0x524197(0x109)](_0x2f9041[_0x524197(0x10d)], { xmlMode: ![] }),
      _0x275f00 = [],
      _0x437564 = [],
      _0x6d294b = [],
      _0x51afd2 = [],
      _0x518839 = [],
      _0x5d18a0 = []
    _0x585cba('div.mozaique\x20>\x20div\x20>\x20div.thumb-under\x20>\x20p.title')[_0x524197(0x145)](
      function (_0x12af35, _0x1d32eb) {
        const _0x3e007c = _0x524197
        _0x275f00[_0x3e007c(0x11c)](
          _0x585cba(this)[_0x3e007c(0x103)]('a')[_0x3e007c(0x135)](_0x3e007c(0x10c))
        ),
          _0x437564[_0x3e007c(0x11c)](_0x585cba(this)[_0x3e007c(0x103)]('span.duration')['text']()),
          _0x51afd2['push'](
            'https://www.xvideos.com' + _0x585cba(this)['find']('a')[_0x3e007c(0x135)]('href')
          )
      }
    ),
      _0x585cba('div.mozaique\x20>\x20div\x20>\x20div.thumb-under')['each'](
        function (_0x10ee54, _0x1189d2) {
          const _0x49edd7 = _0x524197
          _0x6d294b[_0x49edd7(0x11c)](_0x585cba(this)[_0x49edd7(0x103)](_0x49edd7(0x134))['text']())
        }
      ),
      _0x585cba(_0x524197(0x139))[_0x524197(0x145)](function (_0x1f8b18, _0x5a6c0d) {
        const _0x33da6c = _0x524197
        _0x518839['push'](
          _0x585cba(this)[_0x33da6c(0x103)]('img')[_0x33da6c(0x135)](_0x33da6c(0x106))
        )
      })
    for (let _0x3e4544 = 0x0; _0x3e4544 < _0x275f00[_0x524197(0x14f)]; _0x3e4544++) {
      _0x5d18a0['push']({
        title: _0x275f00[_0x3e4544],
        duration: _0x437564[_0x3e4544],
        quality: _0x6d294b[_0x3e4544],
        thumb: _0x518839[_0x3e4544],
        url: _0x51afd2[_0x3e4544],
      })
    }
    _0x610d9(_0x5d18a0)
  })
}
async function xvideosdl(_0x39ce66) {
  return new Promise(async _0xe91861 => {
    const _0x4a2018 = _0x24da,
      _0x375a57 = await _0x3e64a6(_0x39ce66, { method: _0x4a2018(0x111) }),
      _0x4ebd5f = await _0x375a57[_0x4a2018(0x114)](),
      _0x3e2585 = _0xf85905[_0x4a2018(0x109)](_0x4ebd5f, { xmlMode: ![] }),
      _0x47a542 = _0x3e2585(_0x4a2018(0x14a))[_0x4a2018(0x135)](_0x4a2018(0x101)),
      _0xd0dfe7 = _0x3e2585('meta[name=\x27keywords\x27]')[_0x4a2018(0x135)](_0x4a2018(0x101)),
      _0x404174 = _0x3e2585(_0x4a2018(0x10a))[_0x4a2018(0x114)]() + _0x4a2018(0x13a),
      _0x4e685d = _0x3e2585('div.rate-infos\x20>\x20span.rating-total-txt')['text'](),
      _0x4799de = _0x3e2585('span.rating-good-nbr')[_0x4a2018(0x114)](),
      _0x262293 = _0x3e2585(_0x4a2018(0x149))[_0x4a2018(0x114)](),
      _0x1a15c1 = _0x3e2585('meta[property=\x27og:image\x27]')['attr'](_0x4a2018(0x101)),
      _0x28b42c = _0x3e2585(_0x4a2018(0x12f))[_0x4a2018(0x135)](_0x4a2018(0x138))
    _0xe91861({
      status: 0xc8,
      result: {
        title: _0x47a542,
        url: _0x28b42c,
        keyword: _0xd0dfe7,
        views: _0x404174,
        vote: _0x4e685d,
        likes: _0x4799de,
        dislikes: _0x262293,
        thumb: _0x1a15c1,
      },
    })
  })
}
module.exports = {
  sekaikomikDl,
  facebookDl,
  tiktokStalk,
  igStalk,
  xnxxdl,
  xnxxSearch,
  ChatGpt,
  xvideosSearch,
  xvideosdl,
}