const fs = require("fs")
const chalk = require("chalk")
//===========================//\

//===========================//

global.prefa = ['','!','.','#','&']
//===========================//
global.bosstranumber = "60172450429"
global.ownMain = "60177480773"
global.bosstraname = "🪭𝙹 𝙸 ♕ 𝙽 𝚂"
global.botname = "⎝⎝🪭𝙼 𝙰 𝙵 ♕ 𝙸 𝙰🪭"
global.author = "🪭𝙹 𝙸 ♕ 𝙽 𝚂"
global.packname = "🪭𝙼 𝙰 𝙵 ♕ 𝙸 𝙰🪭"
global.link = 'https://chat.whatsapp.com/GOEOOzr0Wc27sD8i3USjb0'
global.yt = "https://youtube.com/@SctCompany"
global.ytname ="SctCompany"
global.socialm = "SecretCompany777"
global.location = "Singapore, Geylang"
global.hiasan = `	◦  `
global.gris = '`'
global.themeemoji = '🩸'
global.tag = `${botname}`

//===========================//

//===========================//


//false=disable and true=enable
global.autoRecording = true //auto recording
global.autoTyping = true //auto typing
global.autorecordtype = false //auto typing + recording
global.autoread = true //auto read messages
global.autobio = true //auto update bio
global.anti92 = false //auto block +92 
global.autoswview = true //auto view status/story
global.typemenu = 'v5'

//API PREMIUM\\
global.APIs = {
	kipas: 'https://api.betabotz.eu.org'
}

global.APIKeys = {
	'https://https://api.betabotz.eu.org': 'kbLVH6gD'
}

global.kipas = 'Jins'
global.logic = 'Saya adalah AI yang dirancang untuk membantu mahasiswa dalam pembahasan coding serta pelajaran umum seperti Matematika, Bahasa Indonesia, Bahasa Inggris, Fisika, Kimia, Rekayasa Perangkat Lunak, dan Basis Data dengan penjelasan yang mudah dipahami dan relevan'

//===========================//

global.xchannel = {
	jid: '120363298524333143@newsletter'
	}

//===========================//

global.country = `60`
global.system = {
gmail: `Bosstra@gmail.com`,
}

//===========================//

global.nick = {
aaa: "⎝⎝⎝🪭𝙱 𝙾 𝚂 𝚂 ♕ 𝚃 𝚁 𝙰🪭乂𝟕𝟕𝟕‏‎‏‎‏‎‏",
sss: "🪭𝚂 𝙰 𝙺 𝚁 𝙰 𝙻 𝚅𝙸𝙸🪭"
}

global.mess = {
    prem: `⎝🪭𝐕𝐈𝐏 𝐎𝐍𝐋𝐘`,
    bugrespon: `⎝🪭𝚆𝙴 𝚆𝙸𝙻𝙻 𝚄𝙿𝙳𝙰𝚃𝙴 𝚈𝙾𝚄𝚁 𝙿𝙰𝚈`,
    success: `⎝⎝🪭𝚂𝚄𝙲𝙲𝙴𝚂𝚂𝙵𝚄𝙻𝙻𝚈 𝙴𝚇𝙴𝙲𝚄𝚃𝙴 𝚃𝙷𝙴 𝚃𝙰𝚁𝙶𝙴𝚃`,
    group: `⎝🪭𝙶𝚁𝙾𝚄𝙿 𝙾𝙽𝙻𝚈 𝙱𝙾𝚂𝚂`,
    admin: `⎝🪭𝙰𝙳𝙼𝙸𝙽 𝙾𝙽𝙻𝚈 𝙱𝙾𝚂𝚂`,
    botAdmin: '⎝🪭𝙱𝙾𝚃 𝙷𝙰𝚁𝚄𝚂 𝙼𝙴𝙽𝙹𝙰𝙳𝙸 𝙰𝙳𝙼𝙸𝙽',
    private: '⎝🪭𝙿𝚁𝙸𝚅𝙰𝚃𝙴 𝙲𝙷𝙰𝚃 𝙾𝙽𝙻𝚈',
    wait: '⎝🪭𝙿𝙻𝙴𝙰𝚂𝙴 𝚆𝙰𝙸𝚃...',    
    error: '⎝🪭𝙴𝚁𝚁𝙾𝚁',
    boss: '⎝⎝⎝🪭𝐁𝐈𝐆𝐁𝐎𝐒𝐒 𝐎𝐍𝐋𝐘',
    done: '⎝🪭𝚂𝚄𝙲𝙲𝙴𝚂𝚂𝙵𝚄𝙻𝙻𝚈'
}
//===========================//

global.thumb = fs.readFileSync('./sevenMedia/thumb.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})