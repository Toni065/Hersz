let handler = async (m, { conn, command }) => {
  await conn.reply(m.chat, wait, m)
  try {
    const res = `https://api.botcahx.eu.org/api/nsfw/${command}?apikey=${btc}`
    await conn.sendFile(m.chat, res, command === 'gifs' ? null : 'nsfw.jpg', '', m)
  } catch (err) {
    console.error(err)
    throw '🚩 Terjadi kesalahan saat mengambil media.'
  }
}

handler.command = handler.help = [
  'gay','ahegao','ass','bdsm','blowjob','cuckold','cum','ero','femdom','foot','gangbang',
  'glasses','hentai','gifs','jahy','manga','masturbation','neko','neko2','orgy','tentacles',
  'pussy','panties','thighs','yuri','zettai'
]

handler.tags = ['nsfw']
handler.limit = true
handler.premium = true // ⬅️ Hanya bisa digunakan oleh user premium

module.exports = handler